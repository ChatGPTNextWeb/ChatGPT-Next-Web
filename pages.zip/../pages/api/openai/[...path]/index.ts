import { prettyObject } from "@/app/utils/format";
import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/app/api/auth";
import { requestOpenai } from "@/app/api/common";

async function handle(
  req: NextRequest,
  { params }: { params: { path: string[] } },
) {
  console.log("[OpenAI Route] params ", params);

  const authResult = auth(req);
  if (authResult.error) {
    return NextResponse.json(authResult, {
      status: 401,
    });
  }

  try {
    return await requestOpenai(req);
  } catch (e) {
    console.error("[OpenAI] ", e);
    return NextResponse.json(prettyObject(e));
  }
}

export const GET = handle;
export const POST = handle;

export default function handler(
  req: NextRequest,
  params: { params: { path: string[] } },
) {
  switch (req.method) {
    case "GET":
      return GET(req, params);
    case "POST":
      return POST(req, params);
    default:
      return NextResponse.json(
        { error: "Invalid request method" },
        { status: 405 },
      );
  }
}

export const runtime = "edge";
