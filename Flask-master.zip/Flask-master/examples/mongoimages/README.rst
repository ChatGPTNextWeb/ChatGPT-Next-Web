MongoEngine and GridFS Example
------------------------------

Simple Contacts application with files and images example. Using MongoEngine support for MongoDB.

Create an Admin user::

    $ fabmanager create-admin

Insert test data::

    $ python testdata.py

Run it::

    $ fabmanager run


