Simple base View exaple
-----------------------

Simple contacts application.

Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask fab create-admin
    $ flask run
